//This is the bridge function that is called by the main code page
function js_run_external_report_types(){
	js_bofa_parser()
}	

 var global_show_debug = true

function js_bofa_parser(){
	
	//*********************************************************************************************************************	
	//*********************************************************************************************************************
	//[[[[[                         		//Fixlet Applicability REPORTS[START]                                      ]]]]]
	//*********************************************************************************************************************
	//*********************************************************************************************************************
		var tmpobjreporttype=new Array() //this is the report type array	
		var report_def = new Object()
		report_def.details = ' (Example using fixlet renderer)'
		report_def.whose = 'whose (name of it contains "MS16-019" and id of site of it = 2 AND (applicable computer count of it > 0  ) AND (not analysis flag of it) and (name of it as lowercase does not contain "corrupt") and (name of it as lowercase does not contain "superseded"))'
		report_def.name = '[BOFA] BOFA Example fixlet applicability report'
		report_def.fn_main_report_render = "js_run_std_main_report"			
		report_def.fn_group_report_render = "js_run_std_group_report"
		tmpobjreporttype.push(report_def)	
	//*********************************************************************************************************************	
	//*********************************************************************************************************************
	//[[[[[                         		//Operator REPORTS[START]                                              	  ]]]]]
	//*********************************************************************************************************************
	//*********************************************************************************************************************
		var report_def = new Object()
		report_def.details = ' (Example using operator renderer)'			
		report_def.whose = 'whose (exist role of it)'
		report_def.name = '[BOFA] Operators with role assigned'
		report_def.fn_main_report_render = "js_run_ops_main_report"				
		tmpobjreporttype.push(report_def)
		
	//*********************************************************************************************************************	
	//*********************************************************************************************************************
	//[[[[[                         		//Relay REPORTS[START]                                              	  ]]]]]
	//*********************************************************************************************************************
	//*********************************************************************************************************************
							
	var report_def = new Object()
	report_def.details = ' (Example using relay renderer)'
	report_def.whose = 'whose (((relay server flag of it) OR (root server flag of it)) and (last report time of it > (now - (7 * day)))) '
	report_def.name = '[BOFA] relays not reported in within last week'
	report_def.fn_main_report_render = "js_run_relay_main_report"				
	tmpobjreporttype.push(report_def)		
		
		//call the importer - This is where things are actually loaded up
	js_report_importer(tmpobjreporttype)	
}




